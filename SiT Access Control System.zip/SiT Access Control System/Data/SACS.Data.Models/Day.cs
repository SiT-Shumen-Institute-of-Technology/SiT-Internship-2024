﻿namespace SACS.Data.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Day
    {
        public char State { get; set; }

        public int WorkedHours { get; set; }

        public virtual Employee Employee { get; set; }

        public int EmployeeId { get; set; }

        public DateTime Date { get; set; }
    }
}
