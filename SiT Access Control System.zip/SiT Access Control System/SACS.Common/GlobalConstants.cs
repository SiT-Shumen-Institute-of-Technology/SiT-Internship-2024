﻿namespace SACS.Common
{
    public static class GlobalConstants
    {
        public const string SystemName = "SACS";

        public const string AdministratorRoleName = "Administrator";
    }
}
